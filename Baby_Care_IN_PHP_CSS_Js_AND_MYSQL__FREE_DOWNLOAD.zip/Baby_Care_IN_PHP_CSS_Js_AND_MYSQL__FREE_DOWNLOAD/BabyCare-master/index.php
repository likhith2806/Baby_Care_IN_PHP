<!--Header: site header with title, description & meta content-->
<?php include 'inc/header.php'; ?>

<!--MENU: navigation bar-->
<?php include 'inc/menu.php'; ?>

<!--//Note: Wellcome note of this website//--> 
<?php include 'inc/welcomesection.php'; ?>
		
<!--//Content: Content of this website //-->
<?php include 'inc/contentsection.php'; ?>

<!--//Footer: footer navigation & social link -->
<?php include 'inc/footer.php'; ?>